//
//  BestPlacesApp.swift
//  BestPlaces
//
//  Created by kristof on 2025. 10. 07..
//

import SwiftUI

@main
struct BestPlacesApp: App {
    var body: some Scene {
        WindowGroup {
            ContentView()
        }
    }
}
